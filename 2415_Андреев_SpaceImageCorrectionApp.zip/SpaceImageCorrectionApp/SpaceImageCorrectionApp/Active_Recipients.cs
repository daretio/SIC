namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Active_Recipients
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int recipient_id { get; set; }

        [StringLength(100)]
        public string recipient_name { get; set; }

        [StringLength(255)]
        public string contact_info { get; set; }

        [StringLength(50)]
        public string country { get; set; }

        public int? acquired_images { get; set; }

        [Column(TypeName = "date")]
        public DateTime? last_acquisition_date { get; set; }
    }
}
