﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Metadata.Edm;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceImageCorrectionApp
{
    public partial class SIC : Form
    {
        private AppContext context;
        public SIC()
        {
            InitializeComponent();
            context = new AppContext();

            admin_grid_ТАБЛИЦА.AllowUserToAddRows = true; 
            admin_grid_ТАБЛИЦА.ReadOnly = false; 

            init_design();
            init_tables();

            init_who_are_you();
            init_quality();
            init_country();

        }

        private void init_design()
        {
            login_btn_ВЫЙТИ.Hide();
            login_ВОШЛИ.Hide();
            login_USERNAME.Hide();

            admin_btn_ДОБАВИТЬ.Hide();
            admin_btn_ОБНОВИТЬ.Hide();
            admin_btn_УДАЛИТЬ.Hide();

            //Если не хотите постоянно входить в даминку для доступа к редактированию БД - закомменьте блок выше и раскомментируйте этот
            /*admin_btn_ДОБАВИТЬ.Show();
            admin_btn_ОБНОВИТЬ.Show();
            admin_btn_УДАЛИТЬ.Show();*/


            login_btn_ВОЙТИ.Show();
            login_text_ЛОГИН.Show();
            login_text_ПАРОЛЬ.Show();
            login_ЛОГИН.Show();
            login_ПАРОЛЬ.Show();
            login_ВХОД.Show();

            login_text_ПАРОЛЬ.PasswordChar = '*';
        }

        private void login_design()
        {
            login_btn_ВЫЙТИ.Show();
            login_ВОШЛИ.Show();
            login_USERNAME.Show();

            login_USERNAME.Text = login_text_ЛОГИН.Text;

            login_btn_ВОЙТИ.Hide();
            login_text_ЛОГИН.Hide();
            login_text_ПАРОЛЬ.Hide();
            login_ЛОГИН.Hide();
            login_ПАРОЛЬ.Hide();
            login_ВХОД.Hide();

            // Простая форма авторизации - редактировать БД можно только в учетной записи администратора
            if (login_USERNAME.Text == "admin" && login_text_ПАРОЛЬ.Text == "admin")
            {
                admin_btn_ДОБАВИТЬ.Show();
                admin_btn_ОБНОВИТЬ.Show();
                admin_btn_УДАЛИТЬ.Show();
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void login_btn_ВОЙТИ_Click(object sender, EventArgs e)
        {
            login_design();
        }

        private void login_btn_ВЫЙТИ_Click(object sender, EventArgs e)
        {
            init_design();
        }

        private void init_who_are_you()
        {
            order_combo_ТИП.Items.Add("Пользователь");
            order_combo_ТИП.Items.Add("Компания");
        }

        private void init_quality()
        {
            order_combo_КАЧЕСТВО.Items.Add("Нормальное");
            order_combo_КАЧЕСТВО.Items.Add("Высокое");
        }

        private void init_country()
        {
            order_combo_СТРАНА.Items.Add("Россия");
            order_combo_СТРАНА.Items.Add("США");
            order_combo_СТРАНА.Items.Add("Япония");
            order_combo_СТРАНА.Items.Add("Другая");
        }

        private void init_price()
        {
            var country = order_combo_СТРАНА.Text;
            var who = order_combo_ТИП.Text;
            var quality = order_combo_КАЧЕСТВО.Text;

            int price = 100;
            string money = "";
            string res = "";

            if (who == "Пользователь") price *= 2;
            else price *= 4;

            if (quality == "Нормальное") price *= 3;
            else price *= 10;

            if (country == "Россия")
            {
                money = "Руб.";
                price *= 1;
            } else if (country == "США")
            {
                money = "Долл.";
                price /= 60;
            } else if (country == "Япония")
            {
                money = "Йен.";
                price /= 5;
            } else
            {
                money = "Евр.";
                price /= 70;
            }

            res = price.ToString() + " " + money;

            order_PRICE.Text = res;
        }

        private void add_to_combo()
        {
            // Добавление не реализовано автоматически с помощью context.Model, т.к. Model почему-то здесь не видится
            admin_combo_ТАБЛИЦА.Items.Add("Acquire");
            admin_combo_ТАБЛИЦА.Items.Add("Companies");
            admin_combo_ТАБЛИЦА.Items.Add("Final_Images");
            admin_combo_ТАБЛИЦА.Items.Add("Image_Correction_Algorithms");
            admin_combo_ТАБЛИЦА.Items.Add("Original_Images");
            admin_combo_ТАБЛИЦА.Items.Add("Private_Person");
            admin_combo_ТАБЛИЦА.Items.Add("Processing");
            admin_combo_ТАБЛИЦА.Items.Add("Processing_Servers");
            admin_combo_ТАБЛИЦА.Items.Add("Receiver_Manufacturers");
            admin_combo_ТАБЛИЦА.Items.Add("Satellites");
            admin_combo_ТАБЛИЦА.Items.Add("Space_Agencies");
        }
        private void init_tables()
        {
            add_to_combo();
        }

        private void order_btn_ОФОРМИТЬ_Click(object sender, EventArgs e)
        {
            

        }

        private void admin_btn_ДОБАВИТЬ_Click(object sender, EventArgs e)
        {
            var selected = admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem;
            if (selected == null)
            {
                MessageBox.Show("Ошибка выбора записи.");
                return;
            }
            var edit_form = new editForm("Добавление", selected);
            if (edit_form.ShowDialog() == DialogResult.OK)
            {
                context = new AppContext();
                show_tables();
            }

        }

        private void admin_btn_ОБНОВИТЬ_Click(object sender, EventArgs e)
        {
            var selected = admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem;
            if (selected == null)
            {
                MessageBox.Show("Ошибка выбора записи.");
                return;
            }

            var edit_form = new editForm("Обновление", selected);
            if (edit_form.ShowDialog() == DialogResult.OK)
            {
                context = new AppContext();
                show_tables();
            }
        }

        private void admin_btn_УДАЛИТЬ_Click(object sender, EventArgs e)
        {
            var selected = admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem;
            if (MessageBox.Show("Удалить запись?", "Подтверждение",
                    MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                switch (selected.GetType().BaseType.Name)
                {
                    case "Satellites": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).satellite_id;

                            var entityToDelete = context.Set(typeof(Satellites)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Satellites)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        } ; break;
                    case "Original_Images": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).image_id;

                            var entityToDelete = context.Set(typeof(Original_Images)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Original_Images)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        } ; break;
                    case "Acquire": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).acquire_id;

                            var entityToDelete = context.Set(typeof(Acquire)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Acquire)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        } ; break;
                    case "Companies": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).company_id;

                            var entityToDelete = context.Set(typeof(Companies)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Companies)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Final_Images": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).final_image_id;

                            var entityToDelete = context.Set(typeof(Final_Images)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Final_Images)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Image_Correction_Algorithms": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).algorithm_id;

                            var entityToDelete = context.Set(typeof(Image_Correction_Algorithms)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Image_Correction_Algorithms)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Private_Persons": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).person_id;

                            var entityToDelete = context.Set(typeof(Private_Person)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Private_Person)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Processing": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).processing_id;

                            var entityToDelete = context.Set(typeof(Processing)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Processing)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Processing_Servers": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).server_id;

                            var entityToDelete = context.Set(typeof(Processing_Servers)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Processing_Servers)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Receiver_Manufacturers": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).manufacturer_id;

                            var entityToDelete = context.Set(typeof(Receiver_Manufacturers)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Receiver_Manufacturers)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Receivers": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).receiver_id;

                            var entityToDelete = context.Set(typeof(Receivers)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Receivers)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Recipients": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).recipient_id;

                            var entityToDelete = context.Set(typeof(Recipients)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Recipients)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Satellite_Manufacturers": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).manufacturer_id;

                            var entityToDelete = context.Set(typeof(Satellite_Manufacturers)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Satellite_Manufacturers)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        }; break;
                    case "Space_Agencies": {
                            var selectedId = ((dynamic)admin_grid_ТАБЛИЦА.CurrentRow.DataBoundItem).agency_id;

                            var entityToDelete = context.Set(typeof(Space_Agencies)).Find(selectedId);

                            if (entityToDelete != null)
                            {
                                context.Set(typeof(Space_Agencies)).Remove(entityToDelete);
                                context.SaveChanges();
                                MessageBox.Show("Запись удалена!");
                            }
                            else MessageBox.Show("Запись не найдена!");
                        } ; break;
                    default:
                        break;
                }
                
            }
            show_tables();
        }

        private void order_btn_ЦЕНА_Click(object sender, EventArgs e)
        {
            init_price();
        }

        private void show_tables()
        {
            if (admin_combo_ТАБЛИЦА.SelectedItem == null)
            {
                MessageBox.Show("Выберите таблицу из списка!");
                return;
            }

            string selectedTable = admin_combo_ТАБЛИЦА.SelectedItem.ToString();
            switch (selectedTable)
            {
                case "Satellites":
                    admin_grid_ТАБЛИЦА.DataSource = context.Satellites.ToList();
                    break;
                case "Original_Images":
                    admin_grid_ТАБЛИЦА.DataSource = context.Original_Images.ToList();
                    break;
                case "Acquire":
                    admin_grid_ТАБЛИЦА.DataSource = context.Acquire.ToList();
                    break;
                case "Companies":
                    admin_grid_ТАБЛИЦА.DataSource = context.Companies.ToList();
                    break;
                case "Final_Images":
                    admin_grid_ТАБЛИЦА.DataSource = context.Final_Images.ToList();
                    break;
                case "Image_Correction_Algorithms":
                    admin_grid_ТАБЛИЦА.DataSource = context.Image_Correction_Algorithms.ToList();
                    break;
                case "Private_Persons":
                    admin_grid_ТАБЛИЦА.DataSource = context.Private_Person.ToList();
                    break;
                case "Processing":
                    admin_grid_ТАБЛИЦА.DataSource = context.Processing.ToList();
                    break;
                case "Processing_Servers":
                    admin_grid_ТАБЛИЦА.DataSource = context.Processing_Servers.ToList();
                    break;
                case "Receiver_Manufacturers":
                    admin_grid_ТАБЛИЦА.DataSource = context.Receiver_Manufacturers.ToList();
                    break;
                case "Receivers":
                    admin_grid_ТАБЛИЦА.DataSource = context.Receivers.ToList();
                    break;
                case "Recipients":
                    admin_grid_ТАБЛИЦА.DataSource = context.Recipients.ToList();
                    break;
                case "Satellite_Manufacturers":
                    admin_grid_ТАБЛИЦА.DataSource = context.Satellite_Manufacturers.ToList();
                    break;
                case "Space_Agencies":
                    admin_grid_ТАБЛИЦА.DataSource = context.Space_Agencies.ToList();
                    break;
                default:
                    MessageBox.Show($"Неизвестная таблица: {selectedTable}");
                    break;
            }
        }

        private void admin_button_ПОКАЗАТЬ_Click(object sender, EventArgs e)
        {
            show_tables();
        }
    }
}
