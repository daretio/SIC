namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Final_Images
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Final_Images()
        {
            Acquire = new HashSet<Acquire>();
            Processing = new HashSet<Processing>();
        }

        [Key]
        public int final_image_id { get; set; }

        [Column(TypeName = "date")]
        public DateTime? retention_date { get; set; }

        [StringLength(255)]
        public string file_path { get; set; }

        [StringLength(20)]
        public string quality_metric { get; set; }

        [StringLength(255)]
        public string description { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Acquire> Acquire { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Processing> Processing { get; set; }
    }
}
