namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Processing_Servers
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Processing_Servers()
        {
            Processing = new HashSet<Processing>();
        }

        [Key]
        public int server_id { get; set; }

        [StringLength(15)]
        public string ip_address { get; set; }

        public int? agency_id { get; set; }

        [StringLength(50)]
        public string serial_number { get; set; }

        [StringLength(50)]
        public string name { get; set; }

        [StringLength(20)]
        public string capacity { get; set; }

        [StringLength(20)]
        public string max_load { get; set; }

        [StringLength(20)]
        public string status { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Processing> Processing { get; set; }

        public virtual Space_Agencies Space_Agencies { get; set; }
    }
}
