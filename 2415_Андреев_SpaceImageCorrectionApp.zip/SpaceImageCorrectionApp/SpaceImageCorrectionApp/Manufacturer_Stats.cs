namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Manufacturer_Stats
    {
        [Key]
        [StringLength(100)]
        public string manufacturer { get; set; }

        public int? satellites_launched { get; set; }

        public int? avg_age_years { get; set; }
    }
}
