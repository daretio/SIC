﻿namespace SpaceImageCorrectionApp
{
    partial class SIC
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TabControl mainWindow;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SIC));
            this.tab_LOGIN = new System.Windows.Forms.TabPage();
            this.login_btn_ВЫЙТИ = new System.Windows.Forms.Button();
            this.login_USERNAME = new System.Windows.Forms.Label();
            this.login_ВОШЛИ = new System.Windows.Forms.Label();
            this.login_btn_ВОЙТИ = new System.Windows.Forms.Button();
            this.login_text_ПАРОЛЬ = new System.Windows.Forms.TextBox();
            this.login_ВХОД = new System.Windows.Forms.Label();
            this.login_ПАРОЛЬ = new System.Windows.Forms.Label();
            this.login_text_ЛОГИН = new System.Windows.Forms.TextBox();
            this.login_ЛОГИН = new System.Windows.Forms.Label();
            this.tab_ORDER = new System.Windows.Forms.TabPage();
            this.order_btn_ЦЕНА = new System.Windows.Forms.Button();
            this.order_combo_СТРАНА = new System.Windows.Forms.ComboBox();
            this.order_text_ПРО = new System.Windows.Forms.TextBox();
            this.order_combo_КАЧЕСТВО = new System.Windows.Forms.ComboBox();
            this.order_КАЧЕСТВО = new System.Windows.Forms.Label();
            this.order_text_ШИРИНА = new System.Windows.Forms.TextBox();
            this.order_text_ШИРОТА = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.order_btn_ОФОРМИТЬ = new System.Windows.Forms.Button();
            this.order_PRICE = new System.Windows.Forms.Label();
            this.order_ЦЕНА = new System.Windows.Forms.Label();
            this.order_КТО = new System.Windows.Forms.Label();
            this.order_ПРО = new System.Windows.Forms.Label();
            this.order_СТРАНА = new System.Windows.Forms.Label();
            this.order_combo_ТИП = new System.Windows.Forms.ComboBox();
            this.order_ПОЧТА = new System.Windows.Forms.Label();
            this.order_ИМЯ = new System.Windows.Forms.Label();
            this.order_text_ИМЯ = new System.Windows.Forms.TextBox();
            this.tab_ADMIN = new System.Windows.Forms.TabPage();
            this.admin_btn_УДАЛИТЬ = new System.Windows.Forms.Button();
            this.admin_btn_ОБНОВИТЬ = new System.Windows.Forms.Button();
            this.admin_btn_ДОБАВИТЬ = new System.Windows.Forms.Button();
            this.admin_grid_ТАБЛИЦА = new System.Windows.Forms.DataGridView();
            this.admin_combo_ТАБЛИЦА = new System.Windows.Forms.ComboBox();
            this.admin_button_ПОКАЗАТЬ = new System.Windows.Forms.Button();
            mainWindow = new System.Windows.Forms.TabControl();
            mainWindow.SuspendLayout();
            this.tab_LOGIN.SuspendLayout();
            this.tab_ORDER.SuspendLayout();
            this.tab_ADMIN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.admin_grid_ТАБЛИЦА)).BeginInit();
            this.SuspendLayout();
            // 
            // mainWindow
            // 
            mainWindow.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            mainWindow.Controls.Add(this.tab_LOGIN);
            mainWindow.Controls.Add(this.tab_ORDER);
            mainWindow.Controls.Add(this.tab_ADMIN);
            mainWindow.ImeMode = System.Windows.Forms.ImeMode.Hangul;
            mainWindow.Location = new System.Drawing.Point(13, 12);
            mainWindow.Name = "mainWindow";
            mainWindow.SelectedIndex = 0;
            mainWindow.Size = new System.Drawing.Size(776, 426);
            mainWindow.TabIndex = 0;
            // 
            // tab_LOGIN
            // 
            this.tab_LOGIN.BackColor = System.Drawing.Color.Transparent;
            this.tab_LOGIN.BackgroundImage = global::SpaceImageCorrectionApp.Properties.Resources.photo_2018_06_04_10_29_49;
            this.tab_LOGIN.Controls.Add(this.login_btn_ВЫЙТИ);
            this.tab_LOGIN.Controls.Add(this.login_USERNAME);
            this.tab_LOGIN.Controls.Add(this.login_ВОШЛИ);
            this.tab_LOGIN.Controls.Add(this.login_btn_ВОЙТИ);
            this.tab_LOGIN.Controls.Add(this.login_text_ПАРОЛЬ);
            this.tab_LOGIN.Controls.Add(this.login_ВХОД);
            this.tab_LOGIN.Controls.Add(this.login_ПАРОЛЬ);
            this.tab_LOGIN.Controls.Add(this.login_text_ЛОГИН);
            this.tab_LOGIN.Controls.Add(this.login_ЛОГИН);
            this.tab_LOGIN.Location = new System.Drawing.Point(4, 28);
            this.tab_LOGIN.Name = "tab_LOGIN";
            this.tab_LOGIN.Padding = new System.Windows.Forms.Padding(3);
            this.tab_LOGIN.Size = new System.Drawing.Size(768, 394);
            this.tab_LOGIN.TabIndex = 0;
            this.tab_LOGIN.Text = "Учетная запись";
            // 
            // login_btn_ВЫЙТИ
            // 
            this.login_btn_ВЫЙТИ.BackColor = System.Drawing.Color.Lime;
            this.login_btn_ВЫЙТИ.Location = new System.Drawing.Point(608, 155);
            this.login_btn_ВЫЙТИ.Name = "login_btn_ВЫЙТИ";
            this.login_btn_ВЫЙТИ.Size = new System.Drawing.Size(136, 35);
            this.login_btn_ВЫЙТИ.TabIndex = 8;
            this.login_btn_ВЫЙТИ.Text = "Выйти";
            this.login_btn_ВЫЙТИ.UseVisualStyleBackColor = false;
            this.login_btn_ВЫЙТИ.Click += new System.EventHandler(this.login_btn_ВЫЙТИ_Click);
            // 
            // login_USERNAME
            // 
            this.login_USERNAME.AutoSize = true;
            this.login_USERNAME.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.login_USERNAME.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.login_USERNAME.Location = new System.Drawing.Point(426, 155);
            this.login_USERNAME.Name = "login_USERNAME";
            this.login_USERNAME.Size = new System.Drawing.Size(72, 29);
            this.login_USERNAME.TabIndex = 7;
            this.login_USERNAME.Text = "Вход";
            // 
            // login_ВОШЛИ
            // 
            this.login_ВОШЛИ.AutoSize = true;
            this.login_ВОШЛИ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.login_ВОШЛИ.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.login_ВОШЛИ.Location = new System.Drawing.Point(28, 154);
            this.login_ВОШЛИ.Name = "login_ВОШЛИ";
            this.login_ВОШЛИ.Size = new System.Drawing.Size(350, 29);
            this.login_ВОШЛИ.TabIndex = 6;
            this.login_ВОШЛИ.Text = "Вы вошли в учетную запись";
            // 
            // login_btn_ВОЙТИ
            // 
            this.login_btn_ВОЙТИ.BackColor = System.Drawing.Color.Lime;
            this.login_btn_ВОЙТИ.Location = new System.Drawing.Point(33, 184);
            this.login_btn_ВОЙТИ.Name = "login_btn_ВОЙТИ";
            this.login_btn_ВОЙТИ.Size = new System.Drawing.Size(711, 46);
            this.login_btn_ВОЙТИ.TabIndex = 5;
            this.login_btn_ВОЙТИ.Text = "Войти";
            this.login_btn_ВОЙТИ.UseVisualStyleBackColor = false;
            this.login_btn_ВОЙТИ.Click += new System.EventHandler(this.login_btn_ВОЙТИ_Click);
            // 
            // login_text_ПАРОЛЬ
            // 
            this.login_text_ПАРОЛЬ.Location = new System.Drawing.Point(96, 129);
            this.login_text_ПАРОЛЬ.Name = "login_text_ПАРОЛЬ";
            this.login_text_ПАРОЛЬ.Size = new System.Drawing.Size(184, 22);
            this.login_text_ПАРОЛЬ.TabIndex = 4;
            // 
            // login_ВХОД
            // 
            this.login_ВХОД.AutoSize = true;
            this.login_ВХОД.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.login_ВХОД.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.login_ВХОД.Location = new System.Drawing.Point(28, 21);
            this.login_ВХОД.Name = "login_ВХОД";
            this.login_ВХОД.Size = new System.Drawing.Size(72, 29);
            this.login_ВХОД.TabIndex = 3;
            this.login_ВХОД.Text = "Вход";
            // 
            // login_ПАРОЛЬ
            // 
            this.login_ПАРОЛЬ.AutoSize = true;
            this.login_ПАРОЛЬ.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.login_ПАРОЛЬ.Location = new System.Drawing.Point(30, 132);
            this.login_ПАРОЛЬ.Name = "login_ПАРОЛЬ";
            this.login_ПАРОЛЬ.Size = new System.Drawing.Size(59, 16);
            this.login_ПАРОЛЬ.TabIndex = 2;
            this.login_ПАРОЛЬ.Text = "Пароль:";
            // 
            // login_text_ЛОГИН
            // 
            this.login_text_ЛОГИН.Location = new System.Drawing.Point(96, 89);
            this.login_text_ЛОГИН.Name = "login_text_ЛОГИН";
            this.login_text_ЛОГИН.Size = new System.Drawing.Size(184, 22);
            this.login_text_ЛОГИН.TabIndex = 1;
            // 
            // login_ЛОГИН
            // 
            this.login_ЛОГИН.AutoSize = true;
            this.login_ЛОГИН.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.login_ЛОГИН.Location = new System.Drawing.Point(30, 92);
            this.login_ЛОГИН.Name = "login_ЛОГИН";
            this.login_ЛОГИН.Size = new System.Drawing.Size(49, 16);
            this.login_ЛОГИН.TabIndex = 0;
            this.login_ЛОГИН.Text = "Логин:";
            // 
            // tab_ORDER
            // 
            this.tab_ORDER.BackgroundImage = global::SpaceImageCorrectionApp.Properties.Resources.photo_2018_06_04_10_29_49;
            this.tab_ORDER.Controls.Add(this.order_btn_ЦЕНА);
            this.tab_ORDER.Controls.Add(this.order_combo_СТРАНА);
            this.tab_ORDER.Controls.Add(this.order_text_ПРО);
            this.tab_ORDER.Controls.Add(this.order_combo_КАЧЕСТВО);
            this.tab_ORDER.Controls.Add(this.order_КАЧЕСТВО);
            this.tab_ORDER.Controls.Add(this.order_text_ШИРИНА);
            this.tab_ORDER.Controls.Add(this.order_text_ШИРОТА);
            this.tab_ORDER.Controls.Add(this.label2);
            this.tab_ORDER.Controls.Add(this.label1);
            this.tab_ORDER.Controls.Add(this.textBox1);
            this.tab_ORDER.Controls.Add(this.order_btn_ОФОРМИТЬ);
            this.tab_ORDER.Controls.Add(this.order_PRICE);
            this.tab_ORDER.Controls.Add(this.order_ЦЕНА);
            this.tab_ORDER.Controls.Add(this.order_КТО);
            this.tab_ORDER.Controls.Add(this.order_ПРО);
            this.tab_ORDER.Controls.Add(this.order_СТРАНА);
            this.tab_ORDER.Controls.Add(this.order_combo_ТИП);
            this.tab_ORDER.Controls.Add(this.order_ПОЧТА);
            this.tab_ORDER.Controls.Add(this.order_ИМЯ);
            this.tab_ORDER.Controls.Add(this.order_text_ИМЯ);
            this.tab_ORDER.Location = new System.Drawing.Point(4, 28);
            this.tab_ORDER.Name = "tab_ORDER";
            this.tab_ORDER.Padding = new System.Windows.Forms.Padding(3);
            this.tab_ORDER.Size = new System.Drawing.Size(768, 394);
            this.tab_ORDER.TabIndex = 1;
            this.tab_ORDER.Text = "Заказ снимка";
            this.tab_ORDER.UseVisualStyleBackColor = true;
            // 
            // order_btn_ЦЕНА
            // 
            this.order_btn_ЦЕНА.BackColor = System.Drawing.Color.Lime;
            this.order_btn_ЦЕНА.Location = new System.Drawing.Point(578, 267);
            this.order_btn_ЦЕНА.Name = "order_btn_ЦЕНА";
            this.order_btn_ЦЕНА.Size = new System.Drawing.Size(173, 33);
            this.order_btn_ЦЕНА.TabIndex = 25;
            this.order_btn_ЦЕНА.Text = "Рассчитать цену";
            this.order_btn_ЦЕНА.UseVisualStyleBackColor = false;
            this.order_btn_ЦЕНА.Click += new System.EventHandler(this.order_btn_ЦЕНА_Click);
            // 
            // order_combo_СТРАНА
            // 
            this.order_combo_СТРАНА.FormattingEnabled = true;
            this.order_combo_СТРАНА.Location = new System.Drawing.Point(578, 78);
            this.order_combo_СТРАНА.Name = "order_combo_СТРАНА";
            this.order_combo_СТРАНА.Size = new System.Drawing.Size(173, 24);
            this.order_combo_СТРАНА.TabIndex = 24;
            // 
            // order_text_ПРО
            // 
            this.order_text_ПРО.Location = new System.Drawing.Point(475, 125);
            this.order_text_ПРО.Name = "order_text_ПРО";
            this.order_text_ПРО.Size = new System.Drawing.Size(276, 22);
            this.order_text_ПРО.TabIndex = 23;
            // 
            // order_combo_КАЧЕСТВО
            // 
            this.order_combo_КАЧЕСТВО.FormattingEnabled = true;
            this.order_combo_КАЧЕСТВО.Location = new System.Drawing.Point(208, 242);
            this.order_combo_КАЧЕСТВО.Name = "order_combo_КАЧЕСТВО";
            this.order_combo_КАЧЕСТВО.Size = new System.Drawing.Size(129, 24);
            this.order_combo_КАЧЕСТВО.TabIndex = 22;
            // 
            // order_КАЧЕСТВО
            // 
            this.order_КАЧЕСТВО.AutoSize = true;
            this.order_КАЧЕСТВО.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.order_КАЧЕСТВО.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.order_КАЧЕСТВО.Location = new System.Drawing.Point(37, 245);
            this.order_КАЧЕСТВО.Name = "order_КАЧЕСТВО";
            this.order_КАЧЕСТВО.Size = new System.Drawing.Size(163, 16);
            this.order_КАЧЕСТВО.TabIndex = 21;
            this.order_КАЧЕСТВО.Text = "Качество изображения:";
            // 
            // order_text_ШИРИНА
            // 
            this.order_text_ШИРИНА.Location = new System.Drawing.Point(153, 187);
            this.order_text_ШИРИНА.Name = "order_text_ШИРИНА";
            this.order_text_ШИРИНА.Size = new System.Drawing.Size(184, 22);
            this.order_text_ШИРИНА.TabIndex = 20;
            // 
            // order_text_ШИРОТА
            // 
            this.order_text_ШИРОТА.Location = new System.Drawing.Point(153, 159);
            this.order_text_ШИРОТА.Name = "order_text_ШИРОТА";
            this.order_text_ШИРОТА.Size = new System.Drawing.Size(184, 22);
            this.order_text_ШИРОТА.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(37, 190);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Долгота снимка:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(37, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 16);
            this.label1.TabIndex = 17;
            this.label1.Text = "Широта снимка:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(567, 47);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(184, 22);
            this.textBox1.TabIndex = 15;
            // 
            // order_btn_ОФОРМИТЬ
            // 
            this.order_btn_ОФОРМИТЬ.BackColor = System.Drawing.Color.Lime;
            this.order_btn_ОФОРМИТЬ.Location = new System.Drawing.Point(40, 322);
            this.order_btn_ОФОРМИТЬ.Name = "order_btn_ОФОРМИТЬ";
            this.order_btn_ОФОРМИТЬ.Size = new System.Drawing.Size(711, 46);
            this.order_btn_ОФОРМИТЬ.TabIndex = 12;
            this.order_btn_ОФОРМИТЬ.Text = "Оформить заказ";
            this.order_btn_ОФОРМИТЬ.UseVisualStyleBackColor = false;
            this.order_btn_ОФОРМИТЬ.Click += new System.EventHandler(this.order_btn_ОФОРМИТЬ_Click);
            // 
            // order_PRICE
            // 
            this.order_PRICE.AutoSize = true;
            this.order_PRICE.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.order_PRICE.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.order_PRICE.Location = new System.Drawing.Point(634, 303);
            this.order_PRICE.Name = "order_PRICE";
            this.order_PRICE.Size = new System.Drawing.Size(11, 16);
            this.order_PRICE.TabIndex = 11;
            this.order_PRICE.Text = "-";
            // 
            // order_ЦЕНА
            // 
            this.order_ЦЕНА.AutoSize = true;
            this.order_ЦЕНА.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.order_ЦЕНА.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.order_ЦЕНА.Location = new System.Drawing.Point(575, 303);
            this.order_ЦЕНА.Name = "order_ЦЕНА";
            this.order_ЦЕНА.Size = new System.Drawing.Size(43, 16);
            this.order_ЦЕНА.TabIndex = 10;
            this.order_ЦЕНА.Text = "Цена:";
            // 
            // order_КТО
            // 
            this.order_КТО.AutoSize = true;
            this.order_КТО.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.order_КТО.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.order_КТО.Location = new System.Drawing.Point(37, 47);
            this.order_КТО.Name = "order_КТО";
            this.order_КТО.Size = new System.Drawing.Size(57, 16);
            this.order_КТО.TabIndex = 9;
            this.order_КТО.Text = "Кто вы?";
            // 
            // order_ПРО
            // 
            this.order_ПРО.AutoSize = true;
            this.order_ПРО.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.order_ПРО.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.order_ПРО.Location = new System.Drawing.Point(472, 106);
            this.order_ПРО.Name = "order_ПРО";
            this.order_ПРО.Size = new System.Drawing.Size(46, 16);
            this.order_ПРО.TabIndex = 7;
            this.order_ПРО.Text = "О вас:";
            // 
            // order_СТРАНА
            // 
            this.order_СТРАНА.AutoSize = true;
            this.order_СТРАНА.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.order_СТРАНА.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.order_СТРАНА.Location = new System.Drawing.Point(472, 78);
            this.order_СТРАНА.Name = "order_СТРАНА";
            this.order_СТРАНА.Size = new System.Drawing.Size(93, 16);
            this.order_СТРАНА.TabIndex = 6;
            this.order_СТРАНА.Text = "Ваша страна:";
            // 
            // order_combo_ТИП
            // 
            this.order_combo_ТИП.FormattingEnabled = true;
            this.order_combo_ТИП.Location = new System.Drawing.Point(100, 44);
            this.order_combo_ТИП.Name = "order_combo_ТИП";
            this.order_combo_ТИП.Size = new System.Drawing.Size(129, 24);
            this.order_combo_ТИП.TabIndex = 5;
            // 
            // order_ПОЧТА
            // 
            this.order_ПОЧТА.AutoSize = true;
            this.order_ПОЧТА.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.order_ПОЧТА.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.order_ПОЧТА.Location = new System.Drawing.Point(472, 50);
            this.order_ПОЧТА.Name = "order_ПОЧТА";
            this.order_ПОЧТА.Size = new System.Drawing.Size(86, 16);
            this.order_ПОЧТА.TabIndex = 4;
            this.order_ПОЧТА.Text = "Ваша почта:";
            this.order_ПОЧТА.Click += new System.EventHandler(this.label7_Click);
            // 
            // order_ИМЯ
            // 
            this.order_ИМЯ.AutoSize = true;
            this.order_ИМЯ.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.order_ИМЯ.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.order_ИМЯ.Location = new System.Drawing.Point(472, 23);
            this.order_ИМЯ.Name = "order_ИМЯ";
            this.order_ИМЯ.Size = new System.Drawing.Size(71, 16);
            this.order_ИМЯ.TabIndex = 3;
            this.order_ИМЯ.Text = "Ваше имя:";
            // 
            // order_text_ИМЯ
            // 
            this.order_text_ИМЯ.Location = new System.Drawing.Point(567, 20);
            this.order_text_ИМЯ.Name = "order_text_ИМЯ";
            this.order_text_ИМЯ.Size = new System.Drawing.Size(184, 22);
            this.order_text_ИМЯ.TabIndex = 2;
            // 
            // tab_ADMIN
            // 
            this.tab_ADMIN.BackgroundImage = global::SpaceImageCorrectionApp.Properties.Resources.photo_2018_06_04_10_29_49;
            this.tab_ADMIN.Controls.Add(this.admin_button_ПОКАЗАТЬ);
            this.tab_ADMIN.Controls.Add(this.admin_btn_УДАЛИТЬ);
            this.tab_ADMIN.Controls.Add(this.admin_btn_ОБНОВИТЬ);
            this.tab_ADMIN.Controls.Add(this.admin_btn_ДОБАВИТЬ);
            this.tab_ADMIN.Controls.Add(this.admin_grid_ТАБЛИЦА);
            this.tab_ADMIN.Controls.Add(this.admin_combo_ТАБЛИЦА);
            this.tab_ADMIN.Location = new System.Drawing.Point(4, 28);
            this.tab_ADMIN.Name = "tab_ADMIN";
            this.tab_ADMIN.Size = new System.Drawing.Size(768, 394);
            this.tab_ADMIN.TabIndex = 2;
            this.tab_ADMIN.Text = "Админ-панель";
            this.tab_ADMIN.UseVisualStyleBackColor = true;
            // 
            // admin_btn_УДАЛИТЬ
            // 
            this.admin_btn_УДАЛИТЬ.BackColor = System.Drawing.Color.Lime;
            this.admin_btn_УДАЛИТЬ.Location = new System.Drawing.Point(3, 345);
            this.admin_btn_УДАЛИТЬ.Name = "admin_btn_УДАЛИТЬ";
            this.admin_btn_УДАЛИТЬ.Size = new System.Drawing.Size(147, 46);
            this.admin_btn_УДАЛИТЬ.TabIndex = 15;
            this.admin_btn_УДАЛИТЬ.Text = "Удаление";
            this.admin_btn_УДАЛИТЬ.UseVisualStyleBackColor = false;
            this.admin_btn_УДАЛИТЬ.Click += new System.EventHandler(this.admin_btn_УДАЛИТЬ_Click);
            // 
            // admin_btn_ОБНОВИТЬ
            // 
            this.admin_btn_ОБНОВИТЬ.BackColor = System.Drawing.Color.Lime;
            this.admin_btn_ОБНОВИТЬ.Location = new System.Drawing.Point(3, 293);
            this.admin_btn_ОБНОВИТЬ.Name = "admin_btn_ОБНОВИТЬ";
            this.admin_btn_ОБНОВИТЬ.Size = new System.Drawing.Size(147, 46);
            this.admin_btn_ОБНОВИТЬ.TabIndex = 14;
            this.admin_btn_ОБНОВИТЬ.Text = "Обновление";
            this.admin_btn_ОБНОВИТЬ.UseVisualStyleBackColor = false;
            this.admin_btn_ОБНОВИТЬ.Click += new System.EventHandler(this.admin_btn_ОБНОВИТЬ_Click);
            // 
            // admin_btn_ДОБАВИТЬ
            // 
            this.admin_btn_ДОБАВИТЬ.BackColor = System.Drawing.Color.Lime;
            this.admin_btn_ДОБАВИТЬ.Location = new System.Drawing.Point(3, 241);
            this.admin_btn_ДОБАВИТЬ.Name = "admin_btn_ДОБАВИТЬ";
            this.admin_btn_ДОБАВИТЬ.Size = new System.Drawing.Size(147, 46);
            this.admin_btn_ДОБАВИТЬ.TabIndex = 13;
            this.admin_btn_ДОБАВИТЬ.Text = "Добавление";
            this.admin_btn_ДОБАВИТЬ.UseVisualStyleBackColor = false;
            this.admin_btn_ДОБАВИТЬ.Click += new System.EventHandler(this.admin_btn_ДОБАВИТЬ_Click);
            // 
            // admin_grid_ТАБЛИЦА
            // 
            this.admin_grid_ТАБЛИЦА.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.admin_grid_ТАБЛИЦА.Location = new System.Drawing.Point(156, 3);
            this.admin_grid_ТАБЛИЦА.Name = "admin_grid_ТАБЛИЦА";
            this.admin_grid_ТАБЛИЦА.RowHeadersWidth = 51;
            this.admin_grid_ТАБЛИЦА.RowTemplate.Height = 24;
            this.admin_grid_ТАБЛИЦА.Size = new System.Drawing.Size(609, 388);
            this.admin_grid_ТАБЛИЦА.TabIndex = 7;
            // 
            // admin_combo_ТАБЛИЦА
            // 
            this.admin_combo_ТАБЛИЦА.FormattingEnabled = true;
            this.admin_combo_ТАБЛИЦА.Location = new System.Drawing.Point(3, 3);
            this.admin_combo_ТАБЛИЦА.Name = "admin_combo_ТАБЛИЦА";
            this.admin_combo_ТАБЛИЦА.Size = new System.Drawing.Size(147, 24);
            this.admin_combo_ТАБЛИЦА.TabIndex = 6;
            // 
            // admin_button_ПОКАЗАТЬ
            // 
            this.admin_button_ПОКАЗАТЬ.BackColor = System.Drawing.Color.Lime;
            this.admin_button_ПОКАЗАТЬ.Location = new System.Drawing.Point(3, 33);
            this.admin_button_ПОКАЗАТЬ.Name = "admin_button_ПОКАЗАТЬ";
            this.admin_button_ПОКАЗАТЬ.Size = new System.Drawing.Size(147, 46);
            this.admin_button_ПОКАЗАТЬ.TabIndex = 16;
            this.admin_button_ПОКАЗАТЬ.Text = "Показать таблицу";
            this.admin_button_ПОКАЗАТЬ.UseVisualStyleBackColor = false;
            this.admin_button_ПОКАЗАТЬ.Click += new System.EventHandler(this.admin_button_ПОКАЗАТЬ_Click);
            // 
            // SIC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(mainWindow);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SIC";
            this.Text = "Приложение для работы с системой SIC";
            mainWindow.ResumeLayout(false);
            this.tab_LOGIN.ResumeLayout(false);
            this.tab_LOGIN.PerformLayout();
            this.tab_ORDER.ResumeLayout(false);
            this.tab_ORDER.PerformLayout();
            this.tab_ADMIN.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.admin_grid_ТАБЛИЦА)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tab_LOGIN;
        private System.Windows.Forms.TabPage tab_ORDER;
        private System.Windows.Forms.TabPage tab_ADMIN;
        private System.Windows.Forms.TextBox login_text_ПАРОЛЬ;
        private System.Windows.Forms.Label login_ВХОД;
        private System.Windows.Forms.Label login_ПАРОЛЬ;
        private System.Windows.Forms.TextBox login_text_ЛОГИН;
        private System.Windows.Forms.Label login_ЛОГИН;
        private System.Windows.Forms.Button login_btn_ВЫЙТИ;
        private System.Windows.Forms.Label login_USERNAME;
        private System.Windows.Forms.Label login_ВОШЛИ;
        private System.Windows.Forms.Button login_btn_ВОЙТИ;
        private System.Windows.Forms.TextBox order_text_ИМЯ;
        private System.Windows.Forms.ComboBox order_combo_ТИП;
        private System.Windows.Forms.Label order_ПОЧТА;
        private System.Windows.Forms.Label order_ИМЯ;
        private System.Windows.Forms.Label order_ПРО;
        private System.Windows.Forms.Label order_СТРАНА;
        private System.Windows.Forms.ComboBox admin_combo_ТАБЛИЦА;
        private System.Windows.Forms.Button order_btn_ОФОРМИТЬ;
        private System.Windows.Forms.Label order_PRICE;
        private System.Windows.Forms.Label order_ЦЕНА;
        private System.Windows.Forms.Label order_КТО;
        private System.Windows.Forms.Button admin_btn_УДАЛИТЬ;
        private System.Windows.Forms.Button admin_btn_ОБНОВИТЬ;
        private System.Windows.Forms.Button admin_btn_ДОБАВИТЬ;
        private System.Windows.Forms.DataGridView admin_grid_ТАБЛИЦА;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox order_text_ШИРИНА;
        private System.Windows.Forms.TextBox order_text_ШИРОТА;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox order_combo_КАЧЕСТВО;
        private System.Windows.Forms.Label order_КАЧЕСТВО;
        private System.Windows.Forms.TextBox order_text_ПРО;
        private System.Windows.Forms.ComboBox order_combo_СТРАНА;
        private System.Windows.Forms.Button order_btn_ЦЕНА;
        private System.Windows.Forms.Button admin_button_ПОКАЗАТЬ;
    }
}

