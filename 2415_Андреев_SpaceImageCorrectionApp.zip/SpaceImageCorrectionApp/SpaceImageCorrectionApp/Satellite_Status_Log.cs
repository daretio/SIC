namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Satellite_Status_Log
    {
        [Key]
        public int log_id { get; set; }

        public int? satellite_id { get; set; }

        [StringLength(20)]
        public string old_status { get; set; }

        [StringLength(20)]
        public string new_status { get; set; }

        public DateTime? change_date { get; set; }
    }
}
