namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Processing")]
    public partial class Processing
    {
        [Key]
        public int processing_id { get; set; }

        public int? original_image_id { get; set; }

        public int? algorithm_id { get; set; }

        public int? server_id { get; set; }

        public int? final_image_id { get; set; }

        public DateTime? timestamp { get; set; }

        public virtual Final_Images Final_Images { get; set; }

        public virtual Image_Correction_Algorithms Image_Correction_Algorithms { get; set; }

        public virtual Original_Images Original_Images { get; set; }

        public virtual Processing_Servers Processing_Servers { get; set; }
    }
}
