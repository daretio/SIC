namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Original_Images
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Original_Images()
        {
            Processing = new HashSet<Processing>();
        }

        [Key]
        public int image_id { get; set; }

        public int? satellite_id { get; set; }

        public int? receiver_id { get; set; }

        public DateTime? capture_date { get; set; }

        [StringLength(255)]
        public string file_path { get; set; }

        [StringLength(20)]
        public string file_size { get; set; }

        public decimal? latitude { get; set; }

        public decimal? longitude { get; set; }

        public virtual Receivers Receivers { get; set; }

        public virtual Satellites Satellites { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Processing> Processing { get; set; }
    }
}
