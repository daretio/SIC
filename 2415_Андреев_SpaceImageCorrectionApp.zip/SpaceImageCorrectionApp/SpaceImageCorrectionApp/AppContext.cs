using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace SpaceImageCorrectionApp
{
    public partial class AppContext : DbContext
    {
        public AppContext()
            : base("name=SIC_Application")
        {
        }

        public virtual DbSet<Acquire> Acquire { get; set; }
        public virtual DbSet<Companies> Companies { get; set; }
        public virtual DbSet<Final_Images> Final_Images { get; set; }
        public virtual DbSet<Image_Correction_Algorithms> Image_Correction_Algorithms { get; set; }
        public virtual DbSet<Original_Images> Original_Images { get; set; }
        public virtual DbSet<Private_Person> Private_Person { get; set; }
        public virtual DbSet<Processing> Processing { get; set; }
        public virtual DbSet<Processing_Servers> Processing_Servers { get; set; }
        public virtual DbSet<Receiver_Manufacturers> Receiver_Manufacturers { get; set; }
        public virtual DbSet<Receivers> Receivers { get; set; }
        public virtual DbSet<Recipients> Recipients { get; set; }
        public virtual DbSet<Satellite_Manufacturers> Satellite_Manufacturers { get; set; }
        public virtual DbSet<Satellite_Status_Log> Satellite_Status_Log { get; set; }
        public virtual DbSet<Satellites> Satellites { get; set; }
        public virtual DbSet<Space_Agencies> Space_Agencies { get; set; }
        public virtual DbSet<Active_Recipients> Active_Recipients { get; set; }
        public virtual DbSet<Manufacturer_Stats> Manufacturer_Stats { get; set; }
        public virtual DbSet<Satellite_Summary> Satellite_Summary { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Acquire>()
                .Property(e => e.price)
                .IsUnicode(false);

            modelBuilder.Entity<Companies>()
                .Property(e => e.director)
                .IsUnicode(false);

            modelBuilder.Entity<Companies>()
                .Property(e => e.revenue)
                .IsUnicode(false);

            modelBuilder.Entity<Final_Images>()
                .Property(e => e.file_path)
                .IsUnicode(false);

            modelBuilder.Entity<Final_Images>()
                .Property(e => e.quality_metric)
                .IsUnicode(false);

            modelBuilder.Entity<Final_Images>()
                .HasMany(e => e.Acquire)
                .WithOptional(e => e.Final_Images)
                .HasForeignKey(e => e.image_id);

            modelBuilder.Entity<Image_Correction_Algorithms>()
                .Property(e => e.name)
                .IsUnicode(false);

            modelBuilder.Entity<Image_Correction_Algorithms>()
                .Property(e => e.version)
                .IsUnicode(false);

            modelBuilder.Entity<Image_Correction_Algorithms>()
                .Property(e => e.code)
                .IsUnicode(false);

            modelBuilder.Entity<Original_Images>()
                .Property(e => e.file_path)
                .IsUnicode(false);

            modelBuilder.Entity<Original_Images>()
                .Property(e => e.file_size)
                .IsUnicode(false);

            modelBuilder.Entity<Original_Images>()
                .Property(e => e.latitude)
                .HasPrecision(9, 6);

            modelBuilder.Entity<Original_Images>()
                .Property(e => e.longitude)
                .HasPrecision(9, 6);

            modelBuilder.Entity<Original_Images>()
                .HasMany(e => e.Processing)
                .WithOptional(e => e.Original_Images)
                .HasForeignKey(e => e.original_image_id);

            modelBuilder.Entity<Private_Person>()
                .Property(e => e.name)
                .IsUnicode(false);

            modelBuilder.Entity<Private_Person>()
                .Property(e => e.about)
                .IsUnicode(false);

            modelBuilder.Entity<Processing_Servers>()
                .Property(e => e.ip_address)
                .IsUnicode(false);

            modelBuilder.Entity<Processing_Servers>()
                .Property(e => e.serial_number)
                .IsUnicode(false);

            modelBuilder.Entity<Processing_Servers>()
                .Property(e => e.name)
                .IsUnicode(false);

            modelBuilder.Entity<Processing_Servers>()
                .Property(e => e.capacity)
                .IsUnicode(false);

            modelBuilder.Entity<Processing_Servers>()
                .Property(e => e.max_load)
                .IsUnicode(false);

            modelBuilder.Entity<Processing_Servers>()
                .Property(e => e.status)
                .IsUnicode(false);

            modelBuilder.Entity<Receiver_Manufacturers>()
                .Property(e => e.country)
                .IsUnicode(false);

            modelBuilder.Entity<Receiver_Manufacturers>()
                .Property(e => e.director)
                .IsUnicode(false);

            modelBuilder.Entity<Receiver_Manufacturers>()
                .Property(e => e.contact_info)
                .IsUnicode(false);

            modelBuilder.Entity<Receivers>()
                .Property(e => e.sensitivity)
                .IsUnicode(false);

            modelBuilder.Entity<Receivers>()
                .Property(e => e.frequency_range)
                .IsUnicode(false);

            modelBuilder.Entity<Receivers>()
                .Property(e => e.region)
                .IsUnicode(false);

            modelBuilder.Entity<Receivers>()
                .Property(e => e.status)
                .IsUnicode(false);

            modelBuilder.Entity<Recipients>()
                .Property(e => e.contact_info)
                .IsUnicode(false);

            modelBuilder.Entity<Recipients>()
                .Property(e => e.country)
                .IsUnicode(false);

            modelBuilder.Entity<Recipients>()
                .HasOptional(e => e.Companies)
                .WithRequired(e => e.Recipients);

            modelBuilder.Entity<Recipients>()
                .HasOptional(e => e.Private_Person)
                .WithRequired(e => e.Recipients);

            modelBuilder.Entity<Satellite_Manufacturers>()
                .Property(e => e.country)
                .IsUnicode(false);

            modelBuilder.Entity<Satellite_Manufacturers>()
                .Property(e => e.director)
                .IsUnicode(false);

            modelBuilder.Entity<Satellite_Manufacturers>()
                .Property(e => e.contact_info)
                .IsUnicode(false);

            modelBuilder.Entity<Satellite_Status_Log>()
                .Property(e => e.old_status)
                .IsUnicode(false);

            modelBuilder.Entity<Satellite_Status_Log>()
                .Property(e => e.new_status)
                .IsUnicode(false);

            modelBuilder.Entity<Satellites>()
                .Property(e => e.orbit_type)
                .IsUnicode(false);

            modelBuilder.Entity<Satellites>()
                .Property(e => e.status)
                .IsUnicode(false);

            modelBuilder.Entity<Space_Agencies>()
                .Property(e => e.name)
                .IsUnicode(false);

            modelBuilder.Entity<Space_Agencies>()
                .Property(e => e.country)
                .IsUnicode(false);

            modelBuilder.Entity<Space_Agencies>()
                .Property(e => e.director)
                .IsUnicode(false);

            modelBuilder.Entity<Space_Agencies>()
                .Property(e => e.contact_info)
                .IsUnicode(false);

            modelBuilder.Entity<Active_Recipients>()
                .Property(e => e.contact_info)
                .IsUnicode(false);

            modelBuilder.Entity<Active_Recipients>()
                .Property(e => e.country)
                .IsUnicode(false);

            modelBuilder.Entity<Satellite_Summary>()
                .Property(e => e.agency)
                .IsUnicode(false);

            modelBuilder.Entity<Satellite_Summary>()
                .Property(e => e.orbit_type)
                .IsUnicode(false);
        }
    }
}
