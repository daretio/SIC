namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Recipients
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Recipients()
        {
            Acquire = new HashSet<Acquire>();
        }

        [Key]
        public int recipient_id { get; set; }

        [StringLength(255)]
        public string contact_info { get; set; }

        [StringLength(50)]
        public string country { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Acquire> Acquire { get; set; }

        public virtual Companies Companies { get; set; }

        public virtual Private_Person Private_Person { get; set; }
    }
}
