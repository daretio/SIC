namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Receiver_Manufacturers
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Receiver_Manufacturers()
        {
            Receivers = new HashSet<Receivers>();
        }

        [Key]
        public int manufacturer_id { get; set; }

        [Required]
        [StringLength(100)]
        public string name { get; set; }

        [StringLength(50)]
        public string country { get; set; }

        public int? founded_year { get; set; }

        [StringLength(100)]
        public string director { get; set; }

        [StringLength(255)]
        public string contact_info { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Receivers> Receivers { get; set; }
    }
}
