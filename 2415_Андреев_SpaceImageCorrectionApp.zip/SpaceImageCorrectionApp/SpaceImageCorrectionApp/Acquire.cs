namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Acquire")]
    public partial class Acquire
    {
        [Key]
        public int acquire_id { get; set; }

        public int? image_id { get; set; }

        public int? recipient_id { get; set; }

        [Column(TypeName = "date")]
        public DateTime? date { get; set; }

        [StringLength(20)]
        public string price { get; set; }

        public virtual Final_Images Final_Images { get; set; }

        public virtual Recipients Recipients { get; set; }
    }
}
