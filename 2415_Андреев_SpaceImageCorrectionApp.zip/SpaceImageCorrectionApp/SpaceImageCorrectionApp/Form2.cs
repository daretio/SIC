﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceImageCorrectionApp
{
    public partial class editForm : Form
    {
        private AppContext context;
        private object _entity;
        private string _mode;
        private Type _entityType;

        public editForm(string mode, object entity = null)
        {
            InitializeComponent();
            context = new AppContext();
            _entity = entity;
            _mode = mode;
        }


        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void show_all()
        {
            edit_text1.Show();
            edit_label1.Show();
            edit_text2.Show();
            edit_label2.Show();
            edit_text3.Show();
            edit_label3.Show();
            edit_text4.Show();
            edit_label4.Show();
            edit_text5.Show();
            edit_label5.Show();
            edit_text6.Show();
            edit_label6.Show();
            edit_text7.Show();
            edit_label7.Show();
            edit_text8.Show();
            edit_label8.Show();
        }

        private void editForm_Load(object sender, EventArgs e)
        {
            show_all();
            if (_entity != null)
            {
                switch (_entity.GetType().BaseType.Name)
                {
                    case "Satellites": _entityType = typeof(Satellites); break;
                    case "Original_Images": _entityType = typeof(Original_Images); break;
                    case "Acquire": _entityType = typeof(Acquire); break;
                    case "Companies": _entityType = typeof(Companies); break;
                    case "Final_Images": _entityType = typeof(Final_Images); break;
                    case "Image_Correction_Algorithms": _entityType = typeof(Image_Correction_Algorithms); break;
                    case "Private_Persons": _entityType = typeof(Private_Person); break;
                    case "Processing": _entityType = typeof(Processing); break;
                    case "Processing_Servers": _entityType = typeof(Processing_Servers); break;
                    case "Receiver_Manufacturers": _entityType = typeof(Receiver_Manufacturers); break;
                    case "Receivers": _entityType = typeof(Receivers); break;
                    case "Recipients": _entityType = typeof(Recipients); break;
                    case "Satellite_Manufacturers": _entityType = typeof(Satellite_Manufacturers); break;
                    case "Space_Agencies": _entityType = typeof(Space_Agencies); break;
                    default:
                        break;
                }
                        switch (_entity.GetType().BaseType.Name)
                {
                    case "Satellites":

                        var table = _entity as Satellites;

                        edit_text1.Text = table.name;
                        edit_label1.Text = "Имя спутника:";
                        edit_text2.Text = table.manufacturer_id.ToString();
                        edit_label2.Text = "Номер производителя:";
                        edit_text3.Text = table.agency_id.ToString();
                        edit_label3.Text = "Номер агентства:";
                        edit_text4.Text = table.launch_date?.ToString("yyyy-mm-dd");
                        edit_label4.Text = "Дата запуска:";
                        edit_text5.Text = table.orbit_type;
                        edit_label5.Text = "Тип орбиты спутника:";
                        edit_text6.Text = table.status;
                        edit_label6.Text = "Статус спутника:";
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();

                        if (_mode == "Добавление") { edit_button.Text = "Добавить новый спутник"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить информацию о спутнике"; }
                        break;

                    case "Original_Images":
                        var orig = _entity as Original_Images;

                        edit_text1.Text = orig.satellite_id.ToString();
                        edit_label1.Text = "Номер спутника:";
                        edit_text2.Text = orig.receiver_id.ToString();
                        edit_label2.Text = "Номер приёмника:";
                        edit_text3.Text = orig.capture_date.ToString();
                        edit_label3.Text = "Дата съёмки:";
                        edit_text4.Text = orig.file_path;
                        edit_label4.Text = "Путь к файлу:";
                        edit_text5.Text = orig.file_size;
                        edit_label5.Text = "Размер файла:";
                        edit_text6.Text = orig.latitude.ToString();
                        edit_label6.Text = "Широта съёмки:";
                        edit_text7.Text = orig.longitude.ToString();
                        edit_label7.Text = "Долгота съёмки:";
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить исходный снимок"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить исходный снимок"; }
                        break;

                    case "Acquire":
                        var acq = _entity as Acquire;

                        edit_text1.Hide();
                        edit_label1.Hide();
                        edit_text2.Text = acq.image_id.ToString();
                        edit_label2.Text = "Номер изображения:";
                        edit_text3.Text = acq.date.ToString();
                        edit_label3.Text = "Дата готовности:";
                        edit_text4.Text = acq.price;
                        edit_label4.Text = "Цена:";
                        edit_text5.Hide();
                        edit_label5.Hide();
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить акт приобретения"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить акт приобретения"; }
                        break;

                    case "Companies":
                        var comp = _entity as Companies;

                        edit_text1.Hide();
                        edit_label1.Hide();
                        edit_text2.Text = comp.name;
                        edit_label2.Text = "Название компании:";
                        edit_text3.Text = comp.director;
                        edit_label3.Text = "Директор:";
                        edit_text4.Text = comp.revenue;
                        edit_label4.Text = "Выручка за прошедший год:";
                        edit_text5.Hide();
                        edit_label5.Hide();
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить компанию"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить информацию о компании"; }
                        break;

                    case "Final_Images":
                        var fin = _entity as Final_Images;

                        edit_text1.Text = fin.retention_date.ToString();
                        edit_label1.Text = "Дата получения:";
                        edit_text2.Text = fin.file_path;
                        edit_label2.Text = "Путь к файлу:";
                        edit_text3.Text = fin.quality_metric;
                        edit_label3.Text = "Оценка качества обработки:";
                        edit_text4.Text = fin.description;
                        edit_label4.Text = "Описание:";
                        edit_text5.Hide();
                        edit_label5.Hide();
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить финальный снимок"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить финальный снимок"; }
                        break;

                    case "Image_Correction_Algorithms":
                        var cor = _entity as Image_Correction_Algorithms;

                        edit_text1.Text = cor.name;
                        edit_label1.Text = "Название алгоритма:";
                        edit_text2.Text = cor.version.ToString();
                        edit_label2.Text = "Версия:";
                        edit_text3.Text = cor.description.ToString();
                        edit_label3.Text = "Описание:";
                        edit_text4.Text = cor.code;
                        edit_label4.Text = "Код алгоритма:";
                        edit_text5.Hide();
                        edit_label5.Hide();
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить алгоритм коррекции"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить алгоритм коррекции"; }
                        break;

                    case "Private_Persons":
                        var priv = _entity as Private_Person;

                        edit_text1.Text = priv.name;
                        edit_label1.Text = "Полное имя:";
                        edit_text2.Text = priv.about;
                        edit_label2.Text = "О себе:";
                        edit_text3.Hide();
                        edit_label3.Hide();
                        edit_text4.Hide();
                        edit_label4.Hide();
                        edit_text5.Hide();
                        edit_label5.Hide();
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить частное лицо"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить данные частного лица"; }
                        break;

                    case "Processing":
                        var proc = _entity as Processing;

                        edit_text1.Text = proc.original_image_id.ToString();
                        edit_label1.Text = "Номер начального снимка:";
                        edit_text2.Text = proc.algorithm_id.ToString();
                        edit_label2.Text = "Номер алгоритма:";
                        edit_text3.Text = proc.server_id.ToString();
                        edit_label3.Text = "Номер сервера:";
                        edit_text4.Text = proc.final_image_id.ToString();
                        edit_label4.Text = "Номер конечного снимка:";
                        edit_text5.Text = proc.timestamp.ToString();
                        edit_label5.Text = "Время обработки:";
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить процесс обработки"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить процесс обработки"; }
                        break;

                    case "Processing_Servers":
                        var serv = _entity as Processing_Servers;

                        edit_text1.Text = serv.ip_address.ToString();
                        edit_label1.Text = "IP-adress:";
                        edit_text2.Text = serv.agency_id.ToString();
                        edit_label2.Text = "Номер космического агенства-владельца:";
                        edit_text3.Text = serv.serial_number.ToString();
                        edit_label3.Text = "Серийный номер:";
                        edit_text4.Text = serv.name;
                        edit_label4.Text = "Имя:";
                        edit_text5.Text = serv.capacity;
                        edit_label5.Text = "Размер:";
                        edit_text6.Text = serv.max_load;
                        edit_label6.Text = "Максимальная загрузка:";
                        edit_text7.Text = serv.status;
                        edit_label7.Text = "Статус сервера:";
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить сервер обработки"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить сервер обработки"; }
                        break;

                    case "Receiver_Manufacturers":
                        var rm = _entity as Receiver_Manufacturers;

                        edit_text1.Text = rm.name;
                        edit_label1.Text = "Название производителя:";
                        edit_text2.Text = rm.country;
                        edit_label2.Text = "Страна:";
                        edit_text3.Text = rm.founded_year.ToString();
                        edit_label3.Text = "Год основания:";
                        edit_text4.Text = rm.director;
                        edit_label4.Text = "Имя директора:";
                        edit_text5.Text = rm.contact_info;
                        edit_label5.Text = "Контактная информация:";
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить производителя приёмников"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить производителя приёмников"; }
                        break;

                    case "Receivers":
                        var rec = _entity as Receivers;

                        edit_text1.Text = rec.manufacturer_id.ToString();
                        edit_label1.Text = "Номер производителя:";
                        edit_text2.Text = rec.agency_id.ToString();
                        edit_label2.Text = "Номер агентства-владельца:";
                        edit_text3.Text = rec.model;
                        edit_label3.Text = "Модель:";
                        edit_text4.Text = rec.sensitivity;
                        edit_label4.Text = "Чувствительность:";
                        edit_text5.Text = rec.frequency_range;
                        edit_label5.Text = "Диапазон частот:";
                        edit_text6.Text = rec.installation_date.ToString();
                        edit_label6.Text = "Дата установки:";
                        edit_text7.Text = rec.region;
                        edit_label7.Text = "Регион расположения:";
                        edit_text8.Text = rec.status;
                        edit_label8.Text = "Статус";
                        if (_mode == "Добавление") { edit_button.Text = "Добавить приёмное оборудование"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить приёмное оборудование"; }
                        break;

                    case "Recipients":
                        var recip = _entity as Recipients;

                        edit_text1.Text = recip.contact_info;
                        edit_label1.Text = "Контактная информация:";
                        edit_text2.Text = recip.country;
                        edit_label2.Text = "Страна:";
                        edit_text3.Hide();
                        edit_label3.Hide();
                        edit_text4.Hide();
                        edit_label4.Hide();
                        edit_text5.Hide();
                        edit_label5.Hide();
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить получателя"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить получателя"; }
                        break;

                    case "Satellite_Manufacturers":
                        var sm = _entity as Satellite_Manufacturers;

                        edit_text1.Text = sm.name;
                        edit_label1.Text = "Название:";
                        edit_text2.Text = sm.country;
                        edit_label2.Text = "Страна:";
                        edit_text3.Text = sm.founded_year.ToString();
                        edit_label3.Text = "Год основания:";
                        edit_text4.Text = sm.director;
                        edit_label4.Text = "Директор:";
                        edit_text5.Text = sm.contact_info;
                        edit_label5.Text = "Контактная информация:";
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить производителя спутников"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить производителя спутников"; }
                        break;

                    case "Space_Agencies":
                        var spa = _entity as Space_Agencies;

                        edit_text1.Text = spa.name;
                        edit_label1.Text = "Название:";
                        edit_text2.Text = spa.country;
                        edit_label2.Text = "Страна:";
                        edit_text3.Text = spa.established_date.ToString();
                        edit_label3.Text = "Дата основания:";
                        edit_text4.Text = spa.director;
                        edit_label4.Text = "Директор:";
                        edit_text5.Text = spa.contact_info;
                        edit_label5.Text = "Контактная информация:";
                        edit_text6.Hide();
                        edit_label6.Hide();
                        edit_text7.Hide();
                        edit_label7.Hide();
                        edit_text8.Hide();
                        edit_label8.Hide();
                        if (_mode == "Добавление") { edit_button.Text = "Добавить космическое агентство"; }
                        else if (_mode == "Обновление") { edit_button.Text = "Обновить космическое агентство"; }
                        break;

                    default:
                        MessageBox.Show($"Что-то пошло не так");
                        break;
                }


            } else
            {
 
            }
            
        } 

        private void edit_button_Click(object sender, EventArgs e)
        {
            if (_mode == "Добавление")
            {
                _entity = Activator.CreateInstance(_entityType);
                context.Set(_entityType).Add(_entity);
                MessageBox.Show(_entityType.ToString());

                if (_entityType == typeof(Satellites))
                {
                    var lastId = context.Satellites.Max(k => k.satellite_id);
                    ((Satellites)_entity).satellite_id = lastId + 1;
                    var ent = (Satellites)_entity;

                    ent.name = edit_text1.Text;
                    ent.manufacturer_id = int.Parse(edit_text2.Text);
                    ent.agency_id = int.Parse(edit_text3.Text);
                    if (DateTime.TryParse(edit_text4.Text, out DateTime parsedDate)) ent.launch_date = parsedDate;
                    ent.orbit_type = edit_text5.Text;
                    ent.status = edit_text6.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Acquire)) {
                    var lastId = context.Acquire.Max(k => k.acquire_id);
                    ((Acquire)_entity).acquire_id = lastId + 1;
                    var ent = (Acquire)_entity;

                    ent.image_id = int.Parse(edit_text1.Text);
                    ent.recipient_id = int.Parse(edit_text2.Text);
                    if (DateTime.TryParse(edit_text3.Text, out DateTime parsedDate)) ent.date = parsedDate;
                    ent.price = edit_text4.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Companies)) {
                    var lastId = context.Companies.Max(k => k.company_id);
                    ((Companies)_entity).company_id = lastId + 1;
                    var ent = (Companies)_entity;

                    ent.name = edit_text1.Text;
                    ent.director = edit_text2.Text;
                    ent.revenue = edit_text3.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Private_Person)) {
                    var lastId = context.Private_Person.Max(k => k.person_id);
                    ((Private_Person)_entity).person_id = lastId + 1;
                    var ent = (Private_Person)_entity;

                    ent.name = edit_text1.Text;
                    ent.about = edit_text2.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Processing)) {
                    var lastId = context.Processing.Max(k => k.processing_id);
                    ((Processing)_entity).processing_id = lastId + 1;
                    var ent = (Processing)_entity;

                    ent.original_image_id = int.Parse(edit_text1.Text);
                    ent.algorithm_id = int.Parse(edit_text2.Text);
                    ent.server_id = int.Parse(edit_text3.Text);
                    if (DateTime.TryParse(edit_text5.Text, out DateTime parsedDate)) ent.timestamp = parsedDate;
                    ent.final_image_id = int.Parse(edit_text4.Text);

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Processing_Servers)) {
                    var lastId = context.Processing_Servers.Max(k => k.server_id);
                    ((Processing_Servers)_entity).server_id = lastId + 1;
                    var ent = (Processing_Servers)_entity;

                    ent.ip_address = edit_text1.Text;
                    ent.agency_id = int.Parse(edit_text2.Text);
                    ent.serial_number = edit_text3.Text;
                    ent.name = edit_text4.Text;
                    ent.capacity = edit_text5.Text;
                    ent.max_load = edit_text6.Text;
                    ent.status = edit_text7.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Receiver_Manufacturers)) {
                    var lastId = context.Receiver_Manufacturers.Max(k => k.manufacturer_id);
                    ((Receiver_Manufacturers)_entity).manufacturer_id = lastId + 1;
                    var ent = (Receiver_Manufacturers)_entity;

                    ent.name = edit_text1.Text;
                    ent.country = edit_text2.Text;
                    ent.founded_year = int.Parse(edit_text3.Text);
                    ent.director = edit_text4.Text;
                    ent.contact_info = edit_text5.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Receivers)) {
                    var lastId = context.Receivers.Max(k => k.receiver_id);
                    ((Receivers)_entity).receiver_id = lastId + 1;
                    var ent = (Receivers)_entity;

                    ent.model = edit_text3.Text;
                    ent.manufacturer_id = int.Parse(edit_text1.Text);
                    ent.agency_id = int.Parse(edit_text2.Text);
                    ent.sensitivity = edit_text4.Text;
                    ent.frequency_range = edit_text5.Text;
                    if (DateTime.TryParse(edit_text6.Text, out DateTime parsedDate)) ent.installation_date = parsedDate;
                    ent.region = edit_text7.Text;
                    ent.status = edit_text8.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Recipients)) {
                    var lastId = context.Recipients.Max(k => k.recipient_id);
                    ((Recipients)_entity).recipient_id = lastId + 1;
                    var ent = (Recipients)_entity;

                    ent.contact_info = edit_text1.Text;
                    ent.country = edit_text2.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Satellite_Manufacturers)) {
                    var lastId = context.Satellite_Manufacturers.Max(k => k.manufacturer_id);
                    ((Satellite_Manufacturers)_entity).manufacturer_id = lastId + 1;
                    var ent = (Satellite_Manufacturers)_entity;

                    ent.name = edit_text1.Text;
                    ent.country = edit_text2.Text;
                    ent.founded_year = int.Parse(edit_text3.Text);
                    ent.director = edit_text4.Text;
                    ent.contact_info = edit_text5.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Space_Agencies)) {
                    var lastId = context.Space_Agencies.Max(k => k.agency_id);
                    ((Space_Agencies)_entity).agency_id = lastId + 1;
                    var ent = (Space_Agencies)_entity;

                    ent.name = edit_text1.Text;
                    ent.country = edit_text2.Text;
                    if (DateTime.TryParse(edit_text3.Text, out DateTime parsedDate)) ent.established_date = parsedDate;
                    ent.director = edit_text4.Text;
                    ent.contact_info = edit_text5.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Original_Images)) {
                    var lastId = context.Original_Images.Max(k => k.image_id);
                    ((Original_Images)_entity).image_id = lastId + 1;
                    var ent = (Original_Images)_entity;

                    ent.satellite_id = int.Parse(edit_text1.Text);
                    ent.receiver_id = int.Parse(edit_text2.Text);
                    if (DateTime.TryParse(edit_text3.Text, out DateTime parsedDate)) ent.capture_date = parsedDate;
                    ent.file_path = edit_text4.Text;
                    ent.file_size = edit_text5.Text;
                    ent.latitude = int.Parse(edit_text6.Text);
                    ent.longitude= int.Parse(edit_text7.Text);

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Image_Correction_Algorithms)) {
                    var lastId = context.Image_Correction_Algorithms.Max(k => k.algorithm_id);
                    ((Image_Correction_Algorithms)_entity).algorithm_id = lastId + 1;
                    var ent = (Image_Correction_Algorithms)_entity;

                    ent.name = edit_text1.Text;
                    ent.version = edit_text2.Text;
                    ent.description = edit_text3.Text;
                    ent.code = edit_text4.Text;

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Final_Images)) {
                    var lastId = context.Final_Images.Max(k => k.final_image_id);
                    ((Final_Images)_entity).final_image_id = lastId + 1;
                    var ent = (Final_Images)_entity;

                    ent.file_path = edit_text2.Text;
                    if (DateTime.TryParse(edit_text1.Text, out DateTime parsedDate)) ent.retention_date = parsedDate;
                    ent.quality_metric = edit_text3.Text;
                    ent.description = edit_text4.Text;

                    MessageBox.Show("Успешно!");
                }

            }

            else if (_mode == "Обновление")
            {
                if (_entityType == typeof(Satellites))
                {
                    var kompl = (Satellites)_entity;

                    var ent = context.Satellites.Find(((dynamic)_entity).satellite_id);
                    if (ent != null)
                    {
                        ent.name = edit_text1.Text;
                        ent.manufacturer_id = int.Parse(edit_text2.Text);
                        ent.agency_id = int.Parse(edit_text3.Text);
                        if (DateTime.TryParse(edit_text4.Text, out DateTime parsedDate)) ent.launch_date = parsedDate;
                        ent.orbit_type = edit_text5.Text;
                        ent.status = edit_text6.Text;

                    }
                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Acquire))
                {
                    var ent = context.Acquire.Find(((dynamic)_entity).acquire_id);
                    if (ent != null)
                    {

                        ent.image_id = int.Parse(edit_text1.Text);
                        ent.recipient_id = int.Parse(edit_text2.Text);
                        if (DateTime.TryParse(edit_text3.Text, out DateTime parsedDate)) ent.date = parsedDate;
                        ent.price = edit_text4.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Companies))
                {
                    var ent = context.Companies.Find(((dynamic)_entity).company_id);
                    if (ent != null)
                    {

                        ent.name = edit_text1.Text;
                        ent.director = edit_text2.Text;
                        ent.revenue = edit_text3.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Private_Person))
                {
                    var ent = context.Private_Person.Find(((dynamic)_entity).person_id);
                    if (ent != null)
                    {

                        ent.name = edit_text1.Text;
                        ent.about = edit_text2.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Processing))
                {
                    var ent = context.Processing.Find(((dynamic)_entity).processing_id);
                    if (ent != null)
                    {

                        ent.original_image_id = int.Parse(edit_text1.Text);
                        ent.algorithm_id = int.Parse(edit_text2.Text);
                        ent.server_id = int.Parse(edit_text3.Text);
                        if (DateTime.TryParse(edit_text5.Text, out DateTime parsedDate)) ent.timestamp = parsedDate;
                        ent.final_image_id = int.Parse(edit_text4.Text);
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Processing_Servers))
                {
                    var ent = context.Processing_Servers.Find(((dynamic)_entity).server_id);
                    if (ent != null)
                    {

                        ent.ip_address = edit_text1.Text;
                        ent.agency_id = int.Parse(edit_text2.Text);
                        ent.serial_number = edit_text3.Text;
                        ent.name = edit_text4.Text;
                        ent.capacity = edit_text5.Text;
                        ent.max_load = edit_text6.Text;
                        ent.status = edit_text7.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Receiver_Manufacturers))
                {
                    var ent = context.Receiver_Manufacturers.Find(((dynamic)_entity).manufacturer_id);
                    if (ent != null)
                    {

                        ent.name = edit_text1.Text;
                        ent.country = edit_text2.Text;
                        ent.founded_year = int.Parse(edit_text3.Text);
                        ent.director = edit_text4.Text;
                        ent.contact_info = edit_text5.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Receivers))
                {
                    var ent = context.Receivers.Find(((dynamic)_entity).receiver_id);
                    if (ent != null)
                    {

                        ent.model = edit_text3.Text;
                        ent.manufacturer_id = int.Parse(edit_text1.Text);
                        ent.agency_id = int.Parse(edit_text2.Text);
                        ent.sensitivity = edit_text4.Text;
                        ent.frequency_range = edit_text5.Text;
                        if (DateTime.TryParse(edit_text6.Text, out DateTime parsedDate)) ent.installation_date = parsedDate;
                        ent.region = edit_text7.Text;
                        ent.status = edit_text8.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Recipients))
                {
                    var ent = context.Recipients.Find(((dynamic)_entity).srecipient_id);
                    if (ent != null)
                    {

                        ent.contact_info = edit_text1.Text;
                        ent.country = edit_text2.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Satellite_Manufacturers))
                {
                    var ent = context.Satellite_Manufacturers.Find(((dynamic)_entity).manufacturer_id);
                    if (ent != null)
                    {

                        ent.name = edit_text1.Text;
                        ent.country = edit_text2.Text;
                        ent.founded_year = int.Parse(edit_text3.Text);
                        ent.director = edit_text4.Text;
                        ent.contact_info = edit_text5.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Space_Agencies))
                {
                    var ent = context.Space_Agencies.Find(((dynamic)_entity).agency_id);
                    if (ent != null)
                    {

                        ent.name = edit_text1.Text;
                        ent.country = edit_text2.Text;
                        if (DateTime.TryParse(edit_text3.Text, out DateTime parsedDate)) ent.established_date = parsedDate;
                        ent.director = edit_text4.Text;
                        ent.contact_info = edit_text5.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Original_Images))
                {
                    var ent = context.Original_Images.Find(((dynamic)_entity).image_id);
                    if (ent != null)
                    {

                        ent.satellite_id = int.Parse(edit_text1.Text);
                        ent.receiver_id = int.Parse(edit_text2.Text);
                        if (DateTime.TryParse(edit_text3.Text, out DateTime parsedDate)) ent.capture_date = parsedDate;
                        ent.file_path = edit_text4.Text;
                        ent.file_size = edit_text5.Text;
                        ent.latitude = int.Parse(edit_text6.Text);
                        ent.longitude = int.Parse(edit_text7.Text);
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Image_Correction_Algorithms))
                {
                    var ent = context.Image_Correction_Algorithms.Find(((dynamic)_entity).algorithm_id);
                    if (ent != null)
                    {

                        ent.name = edit_text1.Text;
                        ent.version = edit_text2.Text;
                        ent.description = edit_text3.Text;
                        ent.code = edit_text4.Text;
                    }

                    MessageBox.Show("Успешно!");
                }
                else if (_entityType == typeof(Final_Images))
                {
                    var ent = context.Final_Images.Find(((dynamic)_entity).final_image_id);
                    if (ent != null)
                    {
                        ent.file_path = edit_text2.Text;
                        if (DateTime.TryParse(edit_text1.Text, out DateTime parsedDate)) ent.retention_date = parsedDate;
                        ent.quality_metric = edit_text3.Text;
                        ent.description = edit_text4.Text;
                    }

                    MessageBox.Show("Успешно!");
                }

            }

            

            context.SaveChanges();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}

