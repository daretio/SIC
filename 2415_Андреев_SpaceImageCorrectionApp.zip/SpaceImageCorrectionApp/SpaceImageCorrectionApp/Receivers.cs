namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Receivers
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Receivers()
        {
            Original_Images = new HashSet<Original_Images>();
        }

        [Key]
        public int receiver_id { get; set; }

        public int? manufacturer_id { get; set; }

        public int? agency_id { get; set; }

        [StringLength(50)]
        public string model { get; set; }

        [StringLength(20)]
        public string sensitivity { get; set; }

        [StringLength(50)]
        public string frequency_range { get; set; }

        [Column(TypeName = "date")]
        public DateTime? installation_date { get; set; }

        [StringLength(100)]
        public string region { get; set; }

        [StringLength(20)]
        public string status { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Original_Images> Original_Images { get; set; }

        public virtual Receiver_Manufacturers Receiver_Manufacturers { get; set; }

        public virtual Space_Agencies Space_Agencies { get; set; }
    }
}
