﻿namespace SpaceImageCorrectionApp
{
    partial class editForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(editForm));
            this.edit_button = new System.Windows.Forms.Button();
            this.edit_text1 = new System.Windows.Forms.TextBox();
            this.edit_label1 = new System.Windows.Forms.Label();
            this.edit_text2 = new System.Windows.Forms.TextBox();
            this.edit_text3 = new System.Windows.Forms.TextBox();
            this.edit_text4 = new System.Windows.Forms.TextBox();
            this.edit_text5 = new System.Windows.Forms.TextBox();
            this.edit_text6 = new System.Windows.Forms.TextBox();
            this.edit_text7 = new System.Windows.Forms.TextBox();
            this.edit_text8 = new System.Windows.Forms.TextBox();
            this.edit_label2 = new System.Windows.Forms.Label();
            this.edit_label4 = new System.Windows.Forms.Label();
            this.edit_label3 = new System.Windows.Forms.Label();
            this.edit_label8 = new System.Windows.Forms.Label();
            this.edit_label7 = new System.Windows.Forms.Label();
            this.edit_label6 = new System.Windows.Forms.Label();
            this.edit_label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // edit_button
            // 
            this.edit_button.BackColor = System.Drawing.Color.RosyBrown;
            this.edit_button.Location = new System.Drawing.Point(12, 366);
            this.edit_button.Name = "edit_button";
            this.edit_button.Size = new System.Drawing.Size(529, 94);
            this.edit_button.TabIndex = 0;
            this.edit_button.Text = "button1";
            this.edit_button.UseVisualStyleBackColor = false;
            this.edit_button.Click += new System.EventHandler(this.edit_button_Click);
            // 
            // edit_text1
            // 
            this.edit_text1.Location = new System.Drawing.Point(360, 81);
            this.edit_text1.Name = "edit_text1";
            this.edit_text1.Size = new System.Drawing.Size(181, 22);
            this.edit_text1.TabIndex = 1;
            // 
            // edit_label1
            // 
            this.edit_label1.AutoSize = true;
            this.edit_label1.Location = new System.Drawing.Point(40, 84);
            this.edit_label1.Name = "edit_label1";
            this.edit_label1.Size = new System.Drawing.Size(44, 16);
            this.edit_label1.TabIndex = 2;
            this.edit_label1.Text = "label1";
            // 
            // edit_text2
            // 
            this.edit_text2.Location = new System.Drawing.Point(360, 109);
            this.edit_text2.Name = "edit_text2";
            this.edit_text2.Size = new System.Drawing.Size(181, 22);
            this.edit_text2.TabIndex = 3;
            // 
            // edit_text3
            // 
            this.edit_text3.Location = new System.Drawing.Point(360, 137);
            this.edit_text3.Name = "edit_text3";
            this.edit_text3.Size = new System.Drawing.Size(181, 22);
            this.edit_text3.TabIndex = 4;
            // 
            // edit_text4
            // 
            this.edit_text4.Location = new System.Drawing.Point(360, 165);
            this.edit_text4.Name = "edit_text4";
            this.edit_text4.Size = new System.Drawing.Size(181, 22);
            this.edit_text4.TabIndex = 5;
            // 
            // edit_text5
            // 
            this.edit_text5.Location = new System.Drawing.Point(360, 193);
            this.edit_text5.Name = "edit_text5";
            this.edit_text5.Size = new System.Drawing.Size(181, 22);
            this.edit_text5.TabIndex = 6;
            // 
            // edit_text6
            // 
            this.edit_text6.Location = new System.Drawing.Point(360, 221);
            this.edit_text6.Name = "edit_text6";
            this.edit_text6.Size = new System.Drawing.Size(181, 22);
            this.edit_text6.TabIndex = 7;
            // 
            // edit_text7
            // 
            this.edit_text7.Location = new System.Drawing.Point(360, 249);
            this.edit_text7.Name = "edit_text7";
            this.edit_text7.Size = new System.Drawing.Size(181, 22);
            this.edit_text7.TabIndex = 8;
            // 
            // edit_text8
            // 
            this.edit_text8.Location = new System.Drawing.Point(360, 277);
            this.edit_text8.Name = "edit_text8";
            this.edit_text8.Size = new System.Drawing.Size(181, 22);
            this.edit_text8.TabIndex = 9;
            this.edit_text8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // edit_label2
            // 
            this.edit_label2.AutoSize = true;
            this.edit_label2.Location = new System.Drawing.Point(40, 112);
            this.edit_label2.Name = "edit_label2";
            this.edit_label2.Size = new System.Drawing.Size(44, 16);
            this.edit_label2.TabIndex = 10;
            this.edit_label2.Text = "label2";
            // 
            // edit_label4
            // 
            this.edit_label4.AutoSize = true;
            this.edit_label4.Location = new System.Drawing.Point(40, 168);
            this.edit_label4.Name = "edit_label4";
            this.edit_label4.Size = new System.Drawing.Size(44, 16);
            this.edit_label4.TabIndex = 12;
            this.edit_label4.Text = "label3";
            // 
            // edit_label3
            // 
            this.edit_label3.AutoSize = true;
            this.edit_label3.Location = new System.Drawing.Point(40, 140);
            this.edit_label3.Name = "edit_label3";
            this.edit_label3.Size = new System.Drawing.Size(44, 16);
            this.edit_label3.TabIndex = 11;
            this.edit_label3.Text = "label4";
            // 
            // edit_label8
            // 
            this.edit_label8.AutoSize = true;
            this.edit_label8.Location = new System.Drawing.Point(40, 280);
            this.edit_label8.Name = "edit_label8";
            this.edit_label8.Size = new System.Drawing.Size(44, 16);
            this.edit_label8.TabIndex = 16;
            this.edit_label8.Text = "label5";
            // 
            // edit_label7
            // 
            this.edit_label7.AutoSize = true;
            this.edit_label7.Location = new System.Drawing.Point(40, 252);
            this.edit_label7.Name = "edit_label7";
            this.edit_label7.Size = new System.Drawing.Size(44, 16);
            this.edit_label7.TabIndex = 15;
            this.edit_label7.Text = "label6";
            // 
            // edit_label6
            // 
            this.edit_label6.AutoSize = true;
            this.edit_label6.Location = new System.Drawing.Point(40, 224);
            this.edit_label6.Name = "edit_label6";
            this.edit_label6.Size = new System.Drawing.Size(44, 16);
            this.edit_label6.TabIndex = 14;
            this.edit_label6.Text = "label7";
            // 
            // edit_label5
            // 
            this.edit_label5.AutoSize = true;
            this.edit_label5.Location = new System.Drawing.Point(40, 196);
            this.edit_label5.Name = "edit_label5";
            this.edit_label5.Size = new System.Drawing.Size(44, 16);
            this.edit_label5.TabIndex = 13;
            this.edit_label5.Text = "label8";
            // 
            // editForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(564, 535);
            this.Controls.Add(this.edit_label8);
            this.Controls.Add(this.edit_label7);
            this.Controls.Add(this.edit_label6);
            this.Controls.Add(this.edit_label5);
            this.Controls.Add(this.edit_label4);
            this.Controls.Add(this.edit_label3);
            this.Controls.Add(this.edit_label2);
            this.Controls.Add(this.edit_text8);
            this.Controls.Add(this.edit_text7);
            this.Controls.Add(this.edit_text6);
            this.Controls.Add(this.edit_text5);
            this.Controls.Add(this.edit_text4);
            this.Controls.Add(this.edit_text3);
            this.Controls.Add(this.edit_text2);
            this.Controls.Add(this.edit_label1);
            this.Controls.Add(this.edit_text1);
            this.Controls.Add(this.edit_button);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "editForm";
            this.Text = "Редактирование таблицы";
            this.Load += new System.EventHandler(this.editForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button edit_button;
        private System.Windows.Forms.TextBox edit_text1;
        private System.Windows.Forms.Label edit_label1;
        private System.Windows.Forms.TextBox edit_text2;
        private System.Windows.Forms.TextBox edit_text3;
        private System.Windows.Forms.TextBox edit_text4;
        private System.Windows.Forms.TextBox edit_text5;
        private System.Windows.Forms.TextBox edit_text6;
        private System.Windows.Forms.TextBox edit_text7;
        private System.Windows.Forms.TextBox edit_text8;
        private System.Windows.Forms.Label edit_label2;
        private System.Windows.Forms.Label edit_label4;
        private System.Windows.Forms.Label edit_label3;
        private System.Windows.Forms.Label edit_label8;
        private System.Windows.Forms.Label edit_label7;
        private System.Windows.Forms.Label edit_label6;
        private System.Windows.Forms.Label edit_label5;

        /*private void InitializeComponent()
        {
            this.Load += new System.EventHandler(this.editForm_Load);
        }*/
        }
}