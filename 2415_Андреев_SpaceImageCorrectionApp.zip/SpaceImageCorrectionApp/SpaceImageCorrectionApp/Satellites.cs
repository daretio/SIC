namespace SpaceImageCorrectionApp
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Satellites
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Satellites()
        {
            Original_Images = new HashSet<Original_Images>();
        }

        [Key]
        public int satellite_id { get; set; }

        [Required]
        [StringLength(100)]
        public string name { get; set; }

        public int? manufacturer_id { get; set; }

        public int? agency_id { get; set; }

        [Column(TypeName = "date")]
        public DateTime? launch_date { get; set; }

        [StringLength(50)]
        public string orbit_type { get; set; }

        [Required]
        [StringLength(20)]
        public string status { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Original_Images> Original_Images { get; set; }

        public virtual Satellite_Manufacturers Satellite_Manufacturers { get; set; }

        public virtual Space_Agencies Space_Agencies { get; set; }
    }
}
